# RENAME THIS FILE TO creds.py before use!
import os

#Alexa Settings
ProductID = ""
Security_Profile_Description =""
Security_Profile_ID  = ""
Client_ID = ""
Client_Secret = ""

# Alexa Refresh Token
refresh_token = ''